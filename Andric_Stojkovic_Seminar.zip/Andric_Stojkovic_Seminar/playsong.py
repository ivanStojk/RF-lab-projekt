#!/usr/bin/env python3
# -*-coding:utf-8-*-
##############################################
# The MIT License (MIT)
# Copyright (c) 2017 Kevin Walchko
# see LICENSE for full details
##############################################
# play a song
import pycreate2
import time

if __name__ == "__main__":
    port = "COM3"
    # port = "/dev/serial/by-id/usb-FTDI_FT231X_USB_UART_DA01NX3Z-if00-port0"
    bot = pycreate2.Create2(port=port)
    bot.start()
    bot.full()
    # random MIDI songs I found on the inteet
    # they cannot be more than 16 midi notes or really 32 bytes arranged
    # as [(note, duration), ...]
    song = [
        60,
        64,
        62,
        32,
        64,
        64,
        62,
        32,
        65,
        96,
        62,
        32,
        60,
        64,
        59,
        32,
        60,
        64,
        62,
        32,
        64,
        64,
        62,
        32,
        65,
        96,
    ]
    print(">> song len: ", len(song) // 2)
    # song number can be 0-3
    song_num = 0
    bot.createSong(song_num, song)
    time.sleep(0.1)
    how_long = bot.playSong(song_num)
    # The song will run in the back ground, don't interrupt it
    # how_long is the time in seconds for it to finish
    print("Sleep for:", how_long)
    time.sleep(how_long)
